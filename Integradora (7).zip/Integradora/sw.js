// se declara el nombre del cache y los assets para almacenar los archivos al mismo
const devpwa = "pwa-site"
const assets = [
  "/",
  "/index.html",
  "/css/style.css",
  "/js/app.js",
  "/imagenes/art.png",
  "/imagenes/disco-duro.png",
  "/imagenes/enemy.png",
  "/imagenes/facebook.png",
   "/imagenes/gmail.png",
   "/imagenes/localización.png",
   "/imagenes/mando.png",
   "/imagenes/mcrl1.png",
   "/imagenes/mcrl2.png",
   "/imagenes/mcrl3.png",
   "/imagenes/pegi7.png",
   "/imagenes/popit.png",
   "/imagenes/raton.png",
   "/imagenes/registrado.png",
   "/imagenes/teclado.png",
   "/imagenes/unicornio.png",
   "/imagenes/windows.png",
  "/imagenes/game.png",]


self.addEventListener("install", installEvent => {
  installEvent.waitUntil(
    caches.open(devpwa).then(cache => {
      cache.addAll(assets)
    })
  )
})

//recuperar los datos
self.addEventListener("fetch", (e) => {
  e.respondWith(
    caches.match(e.request).then((r) => {
      console.log("[Servicio Worker] Obteniendo recurso: " + e.request.url);
      return (
        r ||
        fetch(e.request).then((response) => {
          return caches.open(devpwa).then((cache) => {
            console.log(
              "[Servicio Worker] Almacena el nuevo recurso: " + e.request.url
            );
            cache.put(e.request, response.clone());
            return response;
          });
        })
      );
    })
  );
});