let games = [

{
    "name": "Noticias",
    "author":"Nuevos personajes disponibles",
    "slug": "popit.png",
},

{
    "name": "Novedades",
    "author":"Se han agregado nuevos niveles",
    "slug": "mando.png",
}

]


function noti(){

var button = document.getElementById("notifications");

Notification.requestPermission().then(function (result) {
if (result === "granted") {
randomNotification();
}
});
}

function randomNotification() {
var randomItem = Math.floor(Math.random() * games.length);
var notifTitle = games[randomItem].name;
var notifBody = "Hay nuevas " + games[randomItem].author + ".";
var notifImg = "imagenes/" + games[randomItem].slug + ".png";
var options = {
body: notifBody,
icon: notifImg,
};
var notif = new Notification(notifTitle, options);
setTimeout(randomNotification, 30000);
};

//<input  type="button" onclick="noti();" value="hola">

